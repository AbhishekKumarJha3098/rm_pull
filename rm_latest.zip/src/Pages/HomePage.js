import React from 'react'
import Tanks from '../Components/Tanks/Tanks'

const HomePage = () => {
  return (
    <div>
      <Tanks/>
    </div>
  )
}

export default HomePage
